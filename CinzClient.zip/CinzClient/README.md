# Cinz Client (Fabric 1.21.1)

## Build
1. Install JDK 21 + Gradle (atau salin folder `src/` ke template Fabric 1.21.1).
2. `gradle wrapper` lalu `./gradlew build` -> hasil di `build/libs/cinzclient-1.0.0.jar`
3. Taruh jar di `mods/` bersama Fabric API 0.102.0+1.21.1.

## Perintah (/cinz)
Name: `/cinz name set Steve`, `mode wave`, `color pink aqua`, `style bold`, `speed 2` (lihat di F5/third person)
Miner: `/cinz mine mode normal|3x3`, `/cinz mine on|off` (tombol V)
Builder: taruh `.nbt`/`.schem` di `.minecraft/schematics/`, lalu `/cinz build load x.schem`, berdiri di titik awal, `/cinz build start` (tombol B)
Music: lihat bagian Spotify di bawah

## Spotify
1. Buat app di https://developer.spotify.com/dashboard, Redirect URI: `http://127.0.0.1:8888/callback`
2. `/cinz music login <clientId>` -> login di browser (sekali saja)
3. Audio tidak bisa dibuka langsung di Minecraft (DRM Spotify). Agar tanpa jendela Spotify, jalankan player headless
   (librespot / spotifyd / spotify-player) lalu pilih dengan `/cinz music device <nama>`.
4. `/cinz music playlist <link>` -> lagu + lirik sinkron (LRCLIB) tampil di HUD. Butuh Spotify Premium.

## Build .jar tanpa install apa-apa (GitHub Actions)
1. Buat repo GitHub baru, upload semua isi folder ini (termasuk folder `.github`).
2. Buka tab **Actions** -> workflow "Build Cinz Client" jalan otomatis (~3-5 menit).
3. Download artifact **CinzClient-jar**, ambil `cinzclient-1.0.0.jar` (bukan yang `-sources`).
4. Taruh di `mods/` bersama Fabric Loader 0.16.5+ dan Fabric API 0.102.0+1.21.1.
