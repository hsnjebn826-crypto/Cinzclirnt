package id.cinz;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.*;
import net.minecraft.nbt.*;
import net.minecraft.registry.Registries;
import net.minecraft.registry.entry.RegistryEntryLookup;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.state.property.Property;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.*;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Stream;

/** Auto builder: mendukung .nbt (vanilla structure) dan .schem (Sponge v2/v3). */
public class AutoBuilder {
    public static class Entry {
        final BlockPos rel; final BlockState state;
        Entry(BlockPos r, BlockState s) { rel = r; state = s; }
    }

    public static volatile boolean running;
    static volatile List<Entry> entries = List.of();
    static String fileName = "-";
    static BlockPos origin;
    static final List<Entry> pending = new ArrayList<>();
    static final Map<BlockPos, Integer> attempts = new HashMap<>();
    static final Map<String, Integer> missing = new LinkedHashMap<>();
    static final int MAX_ATTEMPTS = 4;
    static final double REACH = 4.3;
    static int cooldown, scanTimer, tickCount, lastProgress, bestDone = -1, done, blocked, failed, unloaded, affordable;
    public static String status = "";

    public static Path dir() {
        Path d = FabricLoader.getInstance().getGameDir().resolve("schematics");
        try { Files.createDirectories(d); } catch (Exception ignored) {}
        return d;
    }

    public static List<String> list() {
        try (Stream<Path> s = Files.list(dir())) {
            return s.map(p -> p.getFileName().toString())
                    .filter(n -> n.endsWith(".nbt") || n.endsWith(".schem")).sorted().toList();
        } catch (Exception e) { return List.of(); }
    }

    public static void setOrigin(BlockPos p) { origin = p; CinzClient.msg("Origin build: " + p.toShortString()); }

    // ---------- Loading ----------
    public static void load(String name) {
        new Thread(() -> {
            try {
                Path f = dir().resolve(name);
                if (!Files.exists(f)) throw new Exception("File tidak ada di " + dir());
                if (name.endsWith(".litematic")) throw new Exception("Format .litematic belum didukung. Convert ke .schem/.nbt");
                NbtCompound root = NbtIo.readCompressed(f, NbtSizeTracker.ofUnlimitedBytes());
                List<Entry> list = (root.contains("palette") && root.contains("blocks")) ? readVanilla(root) : readSponge(root);
                entries = list; fileName = name; attempts.clear(); pending.clear(); origin = null;
                CinzClient.msg("Schematic dimuat: " + name + " (" + list.size() + " blok non-air). Berdiri di titik awal lalu /cinz build start");
            } catch (Throwable t) { CinzClient.msg("§cGagal load: " + t.getMessage()); }
        }, "cinz-load").start();
    }

    static boolean skip(BlockState s) {
        return s.isAir() || s.isOf(Blocks.STRUCTURE_VOID) || s.isOf(Blocks.JIGSAW) || s.isOf(Blocks.STRUCTURE_BLOCK);
    }

    static List<Entry> readVanilla(NbtCompound root) {
        NbtList pal = root.getList("palette", 10);
        RegistryEntryLookup<Block> lk = Registries.BLOCK.getReadOnlyWrapper();
        BlockState[] st = new BlockState[pal.size()];
        for (int i = 0; i < st.length; i++) st[i] = NbtHelper.toBlockState(lk, pal.getCompound(i));
        List<Entry> out = new ArrayList<>();
        NbtList blocks = root.getList("blocks", 10);
        for (int i = 0; i < blocks.size(); i++) {
            NbtCompound b = blocks.getCompound(i);
            NbtList pos = b.getList("pos", 3);
            BlockState s = st[b.getInt("state")];
            if (!skip(s)) out.add(new Entry(new BlockPos(pos.getInt(0), pos.getInt(1), pos.getInt(2)), s));
        }
        return out;
    }

    static List<Entry> readSponge(NbtCompound root) throws Exception {
        if (root.contains("Schematic", 10)) root = root.getCompound("Schematic");
        int w = root.getShort("Width") & 0xFFFF, h = root.getShort("Height") & 0xFFFF, l = root.getShort("Length") & 0xFFFF;
        if (w == 0 || h == 0 || l == 0) throw new Exception("Bukan file schematic yang valid");
        NbtCompound palTag; byte[] data;
        if (root.contains("Blocks", 10)) { NbtCompound b = root.getCompound("Blocks"); palTag = b.getCompound("Palette"); data = b.getByteArray("Data"); }
        else { palTag = root.getCompound("Palette"); data = root.getByteArray("BlockData"); }
        Map<Integer, BlockState> pal = new HashMap<>();
        for (String k : palTag.getKeys()) pal.put(palTag.getInt(k), parseState(k));
        List<Entry> out = new ArrayList<>();
        int idx = 0, i = 0;
        while (i < data.length && idx < w * h * l) {
            int val = 0, shift = 0, bt;
            do { bt = data[i++]; val |= (bt & 0x7F) << shift; shift += 7; } while ((bt & 0x80) != 0 && i < data.length);
            int x = idx % w, z = (idx / w) % l, y = idx / (w * l);
            BlockState s = pal.get(val);
            if (s != null && !skip(s)) out.add(new Entry(new BlockPos(x, y, z), s));
            idx++;
        }
        return out;
    }

    static BlockState parseState(String s) {
        String name = s, props = null;
        int i = s.indexOf('[');
        if (i >= 0) { name = s.substring(0, i); props = s.substring(i + 1, s.length() - 1); }
        Block b = Registries.BLOCK.get(Identifier.tryParse(name));
        BlockState st = b.getDefaultState();
        if (props != null) for (String kv : props.split(",")) {
            String[] p = kv.split("=");
            Property<?> pr = b.getStateManager().getProperty(p[0]);
            if (pr != null && p.length > 1) st = setProp(st, pr, p[1]);
        }
        return st;
    }

    static <T extends Comparable<T>> BlockState setProp(BlockState s, Property<T> p, String v) {
        return p.parse(v).map(x -> s.with(p, x)).orElse(s);
    }

    // ---------- Control ----------
    public static void toggle() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (running) stop("dimatikan"); else start(mc);
    }

    public static void start(MinecraftClient mc) {
        if (mc.player == null) return;
        if (entries.isEmpty()) { CinzClient.msg("Belum ada schematic. /cinz build load <file>"); return; }
        if (origin == null) origin = mc.player.getBlockPos();
        if (AutoMiner.enabled) AutoMiner.stop("diganti builder");
        attempts.clear(); pending.clear();
        running = true; scanTimer = 0; cooldown = 0; tickCount = 0; lastProgress = 0; bestDone = -1;
        CinzClient.msg("AutoBuilder mulai: " + fileName + " di " + origin.toShortString());
    }

    public static void stop(String why) {
        running = false; status = "";
        Move.set(MinecraftClient.getInstance(), false);
        CinzClient.msg("AutoBuilder berhenti: " + why);
    }

    public static String report() {
        int total = entries.size();
        return done + "/" + total + " (" + (total == 0 ? 0 : done * 100 / total) + "%) | sisa " + pending.size()
                + " | terhalang " + blocked + " | gagal " + failed + " | chunk belum load " + unloaded;
    }

    // ---------- Scan: sumber kebenaran = isi world ----------
    static void scan(ClientPlayerEntity p, ClientWorld w) {
        pending.clear(); missing.clear();
        done = 0; blocked = 0; failed = 0; unloaded = 0; affordable = 0;
        for (Entry e : entries) {
            BlockPos pos = origin.add(e.rel);
            if (!w.getChunkManager().isChunkLoaded(pos.getX() >> 4, pos.getZ() >> 4)) { unloaded++; continue; }
            BlockState cur = w.getBlockState(pos);
            if (cur.getBlock() == e.state.getBlock()) { done++; attempts.remove(pos); continue; } // sudah ada di world
            if (attempts.getOrDefault(pos, 0) >= MAX_ATTEMPTS) { failed++; continue; }
            if (!cur.isAir() && !cur.isReplaceable()) { blocked++; continue; }
            Item it = e.state.getBlock().asItem();
            if (it == Items.AIR) { attempts.put(pos, MAX_ATTEMPTS); failed++; continue; }
            pending.add(e);
            if (canAfford(p, it)) affordable++; else missing.merge(it.getName().getString(), 1, Integer::sum);
        }
        Vec3d pp = p.getPos();
        pending.sort(Comparator.<Entry>comparingInt(e -> e.rel.getY())
                .thenComparingDouble(e -> Vec3d.ofCenter(origin.add(e.rel)).squaredDistanceTo(pp)));
        if (done > bestDone) { bestDone = done; lastProgress = tickCount; }
        status = report();

        if (pending.isEmpty() && unloaded == 0) {
            running = false; Move.set(MinecraftClient.getInstance(), false);
            if (blocked == 0 && failed == 0) CinzClient.msg("§aAutoBuilder SELESAI 100%: schematic sudah lengkap di world (" + done + " blok).");
            else CinzClient.msg("AutoBuilder selesai dengan sisa: " + report());
        } else if (!pending.isEmpty() && affordable == 0 && unloaded == 0) {
            stop("item kurang: " + missing);
        }
    }

    static boolean canAfford(ClientPlayerEntity p, Item it) { return p.isCreative() || p.getInventory().count(it) > 0; }

    // ---------- Tick ----------
    public static void tick(MinecraftClient mc) {
        if (!running) return;
        ClientPlayerEntity p = mc.player; ClientWorld w = mc.world;
        if (p == null || w == null || mc.interactionManager == null) { running = false; return; }
        if (mc.currentScreen != null) return;
        tickCount++;
        if (--scanTimer <= 0) { scan(p, w); scanTimer = 40; if (!running) return; }
        if (tickCount - lastProgress > 900) { stop("tidak ada kemajuan 45 detik. " + report() + (missing.isEmpty() ? "" : " item kurang: " + missing)); return; }
        if (--cooldown > 0) return;

        Vec3d eye = p.getEyePos();
        BlockPos nearest = null; double nd = Double.MAX_VALUE; boolean acted = false;
        int guard = 0;
        for (Iterator<Entry> it = pending.iterator(); it.hasNext() && guard++ < 4000; ) {
            Entry e = it.next();
            BlockPos pos = origin.add(e.rel);
            if (attempts.getOrDefault(pos, 0) >= MAX_ATTEMPTS) { it.remove(); continue; }
            if (!canAfford(p, e.state.getBlock().asItem())) continue;
            BlockState cur = w.getBlockState(pos);
            if (!cur.isAir() && !cur.isReplaceable()) { it.remove(); continue; }
            double d = eye.squaredDistanceTo(Vec3d.ofCenter(pos));
            if (d <= REACH * REACH) {
                int r = tryPlace(mc, p, w, pos, e.state);
                if (r == 1) { it.remove(); acted = true; break; }
                if (r == 2) { acted = true; break; }
            } else if (d < nd) { nd = d; nearest = pos; }
        }

        if (acted) { Move.set(mc, false); return; }
        if (nearest != null && Config.I.buildWalk) walkTo(mc, p, w, nearest);
        else Move.set(mc, false);
    }

    /** 0 = tidak bisa, 1 = berhasil dicoba, 2 = menunggu (swap item) */
    static int tryPlace(MinecraftClient mc, ClientPlayerEntity p, ClientWorld w, BlockPos pos, BlockState st) {
        Item item = st.getBlock().asItem();
        if (p.getBoundingBox().intersects(new Box(pos))) return 0;
        BlockHitResult hit = findSupport(w, pos);
        if (hit == null) return 0;
        int sel = selectItem(mc, p, item);
        if (sel == 0) return 0;
        if (sel == 2) { cooldown = 3; return 2; }
        ActionResult r = mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, hit);
        if (r.isAccepted()) p.swingHand(Hand.MAIN_HAND);
        attempts.merge(pos, 1, Integer::sum);
        cooldown = Math.max(1, Config.I.buildDelay);
        return 1;
    }

    static BlockHitResult findSupport(ClientWorld w, BlockPos pos) {
        Direction[] order = { Direction.DOWN, Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST, Direction.UP };
        for (Direction d : order) {
            BlockPos nb = pos.offset(d);
            BlockState s = w.getBlockState(nb);
            if (s.isAir() || !s.getFluidState().isEmpty() || s.isReplaceable() || interactive(s)) continue;
            Direction face = d.getOpposite();
            Vec3d hp = Vec3d.ofCenter(nb).add(Vec3d.of(face.getVector()).multiply(0.5));
            return new BlockHitResult(hp, face, nb, false);
        }
        return null;
    }

    static boolean interactive(BlockState s) {
        Block b = s.getBlock();
        return s.hasBlockEntity() || b instanceof DoorBlock || b instanceof TrapdoorBlock || b instanceof FenceGateBlock
                || b instanceof ButtonBlock || b instanceof LeverBlock || b instanceof BedBlock || b instanceof CraftingTableBlock;
    }

    /** 0 = tidak ada item, 1 = siap di tangan, 2 = baru swap, tunggu */
    static int selectItem(MinecraftClient mc, ClientPlayerEntity p, Item item) {
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < 9; i++) if (inv.getStack(i).isOf(item)) { inv.selectedSlot = i; return 1; }
        if (p.isCreative()) {
            ItemStack s = new ItemStack(item);
            inv.setStack(inv.selectedSlot, s);
            mc.interactionManager.clickCreativeStack(s, 36 + inv.selectedSlot);
            return 1;
        }
        for (int i = 9; i < 36; i++) if (inv.getStack(i).isOf(item)) {
            mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, i, inv.selectedSlot, SlotActionType.SWAP, p);
            return 2;
        }
        return 0;
    }

    static void walkTo(MinecraftClient mc, ClientPlayerEntity p, ClientWorld w, BlockPos target) {
        double dx = target.getX() + 0.5 - p.getX(), dz = target.getZ() + 0.5 - p.getZ();
        double hd = Math.sqrt(dx * dx + dz * dz);
        if (hd < 1.5) { Move.set(mc, false); return; }
        p.setYaw((float) Math.toDegrees(Math.atan2(-dx, dz)));
        if (Move.safeAhead(w, p, p.getHorizontalFacing())) {
            Move.set(mc, true);
            mc.options.jumpKey.setPressed(p.horizontalCollision && p.isOnGround());
        } else Move.set(mc, false);
    }
}
