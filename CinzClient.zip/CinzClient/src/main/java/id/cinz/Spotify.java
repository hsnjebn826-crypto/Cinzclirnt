package id.cinz;

import com.google.gson.*;
import net.minecraft.text.Text;
import net.minecraft.util.Util;
import java.io.*;
import java.net.*;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;

/**
 * Remote control Spotify lewat Web API (butuh Premium) + lirik sinkron dari LRCLIB.
 * Audio diputar oleh "device" Spotify (mis. librespot/spotifyd headless), bukan oleh Minecraft.
 */
public class Spotify {
    public record Line(long ms, String text) {}

    static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(8)).build();
    static final ScheduledExecutorService EX = Executors.newSingleThreadScheduledExecutor(r -> { Thread t = new Thread(r, "cinz-spotify"); t.setDaemon(true); return t; });
    static final ExecutorService LYR = Executors.newCachedThreadPool(r -> { Thread t = new Thread(r, "cinz-lyrics"); t.setDaemon(true); return t; });
    static final String REDIRECT = "http://127.0.0.1:8888/callback";
    static final Pattern SP = Pattern.compile("(?:open\\.spotify\\.com/|spotify:)(playlist|album|artist|track)[/:]([A-Za-z0-9]+)");
    static final Pattern LRC = Pattern.compile("^\\[(\\d+):(\\d+(?:\\.\\d+)?)\\]\\s*(.*)$");

    static String access = ""; static long accessExp = 0; static String verifier = "";

    public static volatile String title = "", artist = "", album = "", trackId = "", lyricsInfo = "";
    public static volatile boolean playing, connected, synced;
    public static volatile long durationMs, progressMs, progressAt;
    public static volatile List<Line> lyrics = List.of();

    public static void init() { EX.scheduleWithFixedDelay(Spotify::poll, 2, 2, TimeUnit.SECONDS); }

    // ---------- util ----------
    static String enc(String s) { return URLEncoder.encode(s, StandardCharsets.UTF_8); }
    static String str(JsonObject o, String k) { return o.has(k) && !o.get(k).isJsonNull() ? o.get(k).getAsString() : ""; }

    interface Job { void run() throws Exception; }
    static void run(String label, Job j) {
        EX.execute(() -> {
            try { j.run(); } catch (Exception e) {
                String m = String.valueOf(e.getMessage());
                if (m.contains("403")) m += " (butuh Spotify Premium)";
                CinzClient.msg("§cSpotify " + label + ": " + m);
            }
        });
    }

    // ---------- auth (PKCE) ----------
    public static void login(String clientId) {
        Config.I.spotifyClientId = clientId; Config.save();
        try {
            byte[] rnd = new byte[48]; new SecureRandom().nextBytes(rnd);
            verifier = Base64.getUrlEncoder().withoutPadding().encodeToString(rnd);
            String challenge = Base64.getUrlEncoder().withoutPadding().encodeToString(
                    MessageDigest.getInstance("SHA-256").digest(verifier.getBytes(StandardCharsets.US_ASCII)));
            String url = "https://accounts.spotify.com/authorize?client_id=" + enc(clientId) + "&response_type=code&redirect_uri=" + enc(REDIRECT)
                    + "&code_challenge_method=S256&code_challenge=" + challenge
                    + "&scope=" + enc("user-read-playback-state user-modify-playback-state user-read-currently-playing");
            ServerSocket ss = new ServerSocket(8888, 1, InetAddress.getByName("127.0.0.1"));
            ss.setSoTimeout(180000);
            new Thread(() -> {
                try (ServerSocket s = ss; Socket c = s.accept()) {
                    BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream()));
                    String line = r.readLine(); // GET /callback?code=... HTTP/1.1
                    String code = null;
                    int q = line.indexOf('?'), e = line.indexOf(" HTTP");
                    if (q > 0) for (String kv : line.substring(q + 1, e).split("&")) if (kv.startsWith("code=")) code = URLDecoder.decode(kv.substring(5), StandardCharsets.UTF_8);
                    String html = "<html><body style='font-family:sans-serif'><h2>Cinz Client: login Spotify " + (code != null ? "berhasil" : "gagal") + ". Kembali ke Minecraft.</h2></body></html>";
                    byte[] b = html.getBytes(StandardCharsets.UTF_8);
                    OutputStream os = c.getOutputStream();
                    os.write(("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: " + b.length + "\r\nConnection: close\r\n\r\n").getBytes(StandardCharsets.UTF_8));
                    os.write(b); os.flush();
                    if (code == null) throw new IOException("tidak ada code");
                    exchange(code);
                    CinzClient.msg("§aSpotify login berhasil. Coba /cinz music devices lalu /cinz music play");
                } catch (Exception ex) { CinzClient.msg("§cLogin Spotify gagal: " + ex.getMessage()); }
            }, "cinz-login").start();
            CinzClient.msg("Membuka browser untuk login Spotify. Redirect URI di dashboard harus: " + REDIRECT);
            CinzClient.msgText(Text.literal("§b[Klik jika browser tidak terbuka]").styled(st -> st.withClickEvent(new net.minecraft.text.ClickEvent(net.minecraft.text.ClickEvent.Action.OPEN_URL, url))));
            Util.getOperatingSystem().open(URI.create(url));
        } catch (Exception e) { CinzClient.msg("§cLogin gagal: " + e.getMessage()); }
    }

    static void exchange(String code) throws Exception {
        JsonObject o = tokenReq("grant_type=authorization_code&code=" + enc(code) + "&redirect_uri=" + enc(REDIRECT)
                + "&client_id=" + enc(Config.I.spotifyClientId) + "&code_verifier=" + enc(verifier));
        applyToken(o);
    }

    static JsonObject tokenReq(String form) throws Exception {
        HttpRequest rq = HttpRequest.newBuilder(URI.create("https://accounts.spotify.com/api/token")).timeout(Duration.ofSeconds(10))
                .header("Content-Type", "application/x-www-form-urlencoded").POST(HttpRequest.BodyPublishers.ofString(form)).build();
        HttpResponse<String> r = HTTP.send(rq, HttpResponse.BodyHandlers.ofString());
        if (r.statusCode() >= 400) throw new IOException("token " + r.statusCode() + ": " + r.body());
        return JsonParser.parseString(r.body()).getAsJsonObject();
    }

    static void applyToken(JsonObject o) {
        access = o.get("access_token").getAsString();
        accessExp = System.currentTimeMillis() + o.get("expires_in").getAsLong() * 1000;
        if (o.has("refresh_token")) { Config.I.refreshToken = o.get("refresh_token").getAsString(); Config.save(); }
    }

    static synchronized String token() throws Exception {
        if (!access.isEmpty() && System.currentTimeMillis() < accessExp - 30000) return access;
        if (Config.I.refreshToken.isEmpty()) throw new IOException("Belum login. /cinz music login <clientId>");
        applyToken(tokenReq("grant_type=refresh_token&refresh_token=" + enc(Config.I.refreshToken) + "&client_id=" + enc(Config.I.spotifyClientId)));
        return access;
    }

    // ---------- API ----------
    static JsonObject api(String method, String path, String body) throws Exception {
        HttpRequest.Builder b = HttpRequest.newBuilder(URI.create("https://api.spotify.com/v1" + path))
                .timeout(Duration.ofSeconds(10)).header("Authorization", "Bearer " + token());
        if (body != null) b.header("Content-Type", "application/json");
        b.method(method, body == null ? HttpRequest.BodyPublishers.noBody() : HttpRequest.BodyPublishers.ofString(body));
        HttpResponse<String> r = HTTP.send(b.build(), HttpResponse.BodyHandlers.ofString());
        if (r.statusCode() >= 400) throw new IOException(r.statusCode() + " " + r.body());
        if (r.statusCode() == 204 || r.body().isBlank()) return null;
        return JsonParser.parseString(r.body()).getAsJsonObject();
    }

    static void poll() {
        if (Config.I.refreshToken.isEmpty()) return;
        try {
            JsonObject o = api("GET", "/me/player", null);
            if (o == null || !o.has("item") || o.get("item").isJsonNull()) { connected = false; playing = false; return; }
            connected = true;
            playing = o.get("is_playing").getAsBoolean();
            progressMs = o.has("progress_ms") && !o.get("progress_ms").isJsonNull() ? o.get("progress_ms").getAsLong() : 0;
            progressAt = System.currentTimeMillis();
            JsonObject it = o.getAsJsonObject("item");
            String name = str(it, "name"), id = str(it, "id");
            if (id.isEmpty()) id = name;
            StringBuilder ar = new StringBuilder();
            if (it.has("artists")) for (JsonElement e : it.getAsJsonArray("artists")) { if (ar.length() > 0) ar.append(", "); ar.append(str(e.getAsJsonObject(), "name")); }
            String alb = it.has("album") ? str(it.getAsJsonObject("album"), "name") : "";
            durationMs = it.has("duration_ms") ? it.get("duration_ms").getAsLong() : 0;
            title = name; artist = ar.toString(); album = alb;
            if (!id.equals(trackId)) { trackId = id; fetchLyrics(id, name, artist.split(",")[0].trim(), alb, durationMs); }
        } catch (Exception e) { connected = false; }
    }

    static String device() throws Exception {
        JsonObject o = api("GET", "/me/player/devices", null);
        JsonArray ds = o == null ? new JsonArray() : o.getAsJsonArray("devices");
        if (ds.size() == 0) throw new IOException("Tidak ada device Spotify. Jalankan librespot/spotifyd (headless) atau buka Spotify sekali.");
        String pref = Config.I.spotifyDevice.toLowerCase(), first = null, active = null;
        for (JsonElement e : ds) {
            JsonObject d = e.getAsJsonObject();
            String id = str(d, "id"), n = str(d, "name").toLowerCase();
            if (first == null) first = id;
            if (d.get("is_active").getAsBoolean()) active = id;
            if (!pref.isEmpty() && n.contains(pref)) return id;
        }
        return active != null ? active : first;
    }

    public static void devices() {
        run("devices", () -> {
            JsonObject o = api("GET", "/me/player/devices", null);
            JsonArray ds = o == null ? new JsonArray() : o.getAsJsonArray("devices");
            if (ds.size() == 0) { CinzClient.msg("Tidak ada device."); return; }
            for (JsonElement e : ds) CinzClient.msg("- " + str(e.getAsJsonObject(), "name") + " [" + str(e.getAsJsonObject(), "type") + "]");
        });
    }

    public static void play(String link) {
        run("play", () -> {
            String dev = device();
            JsonObject body = null;
            if (link != null) {
                Matcher m = SP.matcher(link);
                if (!m.find()) throw new IOException("Link/URI Spotify tidak valid");
                body = new JsonObject();
                if (m.group(1).equals("track")) { JsonArray a = new JsonArray(); a.add("spotify:track:" + m.group(2)); body.add("uris", a); }
                else body.addProperty("context_uri", "spotify:" + m.group(1) + ":" + m.group(2));
            }
            api("PUT", "/me/player/play?device_id=" + enc(dev), body == null ? null : body.toString());
        });
    }

    public static void pause() { run("pause", () -> api("PUT", "/me/player/pause", null)); }
    public static void next() { run("next", () -> api("POST", "/me/player/next", null)); }
    public static void prev() { run("prev", () -> api("POST", "/me/player/previous", null)); }
    public static void volume(int v) { run("volume", () -> api("PUT", "/me/player/volume?volume_percent=" + Math.max(0, Math.min(100, v)), null)); }
    public static void shuffle(boolean on) { run("shuffle", () -> api("PUT", "/me/player/shuffle?state=" + on, null)); }

    // ---------- Lyrics (LRCLIB) ----------
    static void fetchLyrics(String id, String name, String art, String alb, long dur) {
        lyrics = List.of(); synced = false; lyricsInfo = "Mencari lirik...";
        LYR.execute(() -> {
            try {
                JsonObject o = null;
                String u = "https://lrclib.net/api/get?track_name=" + enc(name) + "&artist_name=" + enc(art) + "&album_name=" + enc(alb) + "&duration=" + (dur / 1000);
                HttpResponse<String> r = HTTP.send(HttpRequest.newBuilder(URI.create(u)).header("User-Agent", "CinzClient/1.0").timeout(Duration.ofSeconds(10)).build(), HttpResponse.BodyHandlers.ofString());
                if (r.statusCode() == 200) o = JsonParser.parseString(r.body()).getAsJsonObject();
                else {
                    String su = "https://lrclib.net/api/search?track_name=" + enc(name) + "&artist_name=" + enc(art);
                    HttpResponse<String> r2 = HTTP.send(HttpRequest.newBuilder(URI.create(su)).header("User-Agent", "CinzClient/1.0").timeout(Duration.ofSeconds(10)).build(), HttpResponse.BodyHandlers.ofString());
                    if (r2.statusCode() == 200) for (JsonElement e : JsonParser.parseString(r2.body()).getAsJsonArray()) {
                        JsonObject c = e.getAsJsonObject();
                        if (!str(c, "syncedLyrics").isEmpty()) { o = c; break; }
                    }
                }
                if (!id.equals(trackId)) return;
                if (o == null || str(o, "syncedLyrics").isEmpty()) { lyricsInfo = o == null ? "Lirik tidak ditemukan" : "Hanya lirik non-sinkron tersedia"; return; }
                List<Line> ls = new ArrayList<>();
                for (String ln : str(o, "syncedLyrics").split("\n")) {
                    Matcher m = LRC.matcher(ln.trim());
                    if (m.matches()) ls.add(new Line((long) ((Integer.parseInt(m.group(1)) * 60 + Double.parseDouble(m.group(2))) * 1000), m.group(3)));
                }
                if (!id.equals(trackId)) return;
                lyrics = ls; synced = !ls.isEmpty(); lyricsInfo = synced ? "" : "Lirik kosong";
            } catch (Exception e) { lyricsInfo = "Gagal ambil lirik"; }
        });
    }

    public static long position() {
        long p = progressMs;
        if (playing) p += System.currentTimeMillis() - progressAt;
        return Math.min(p, durationMs);
    }

    public static int lineIndex() {
        List<Line> l = lyrics;
        if (l.isEmpty() || !synced) return -1;
        long pos = position(); int idx = -1;
        for (int i = 0; i < l.size(); i++) { if (l.get(i).ms() <= pos) idx = i; else break; }
        return idx;
    }
}
