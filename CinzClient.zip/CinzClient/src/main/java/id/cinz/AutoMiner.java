package id.cinz;

import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import java.util.*;

public class AutoMiner {
    public static boolean enabled;
    public static String status = "";
    static int ticks;

    public static void toggle() { if (enabled) stop("dimatikan"); else start(); }

    public static void start() {
        if (AutoBuilder.running) AutoBuilder.stop("diganti miner");
        enabled = true; ticks = 0;
        CinzClient.msg("AutoMiner ON, mode: " + Config.I.minerMode + (Config.I.minerMode.equals("3X3") ? " (hanya 1 blok di depan)" : " (2 blok: kaki + kepala)"));
    }

    public static void stop(String why) {
        enabled = false; status = "";
        MinecraftClient mc = MinecraftClient.getInstance();
        Move.set(mc, false);
        if (mc.interactionManager != null) mc.interactionManager.cancelBlockBreaking();
        CinzClient.msg("AutoMiner OFF: " + why);
    }

    public static void tick(MinecraftClient mc) {
        if (!enabled) return;
        ClientPlayerEntity p = mc.player; ClientWorld w = mc.world;
        if (p == null || w == null || mc.interactionManager == null) { enabled = false; return; }
        if (mc.currentScreen != null) return;
        ticks++;

        if (p.getHealth() < Config.I.minerMinHealth) { stop("health rendah"); return; }
        if (!p.isCreative() && ticks % 20 == 0 && p.getInventory().getEmptySlot() == -1) { stop("inventory penuh"); return; }

        boolean three = Config.I.minerMode.equals("3X3");
        Direction dir = p.getHorizontalFacing();
        BlockPos feet = p.getBlockPos();
        List<BlockPos> targets = new ArrayList<>();
        if (three) targets.add(feet.up().offset(dir));           // pusat 3x3 = 1 blok di depan
        else { targets.add(feet.offset(dir)); targets.add(feet.up().offset(dir)); } // 2 blok

        BlockPos tgt = null; boolean danger = false;
        for (BlockPos bp : targets) {
            BlockState s = w.getBlockState(bp);
            if (s.isAir()) continue;
            if (!s.getFluidState().isEmpty()) { danger = true; continue; }
            if (s.getHardness(w, bp) < 0) continue; // bedrock dll
            tgt = bp; break;
        }

        if (tgt != null) {
            Move.set(mc, false);
            if (!three) selectBestTool(p, w.getBlockState(tgt));
            ItemStack held = p.getMainHandStack();
            if (!p.isCreative() && held.isDamageable() && held.getMaxDamage() - held.getDamage() <= 2) { stop("tool hampir rusak"); return; }
            mc.interactionManager.updateBlockBreakingProgress(tgt, dir.getOpposite());
            p.swingHand(Hand.MAIN_HAND);
            status = "Mining " + w.getBlockState(tgt).getBlock().getName().getString();
        } else {
            mc.interactionManager.cancelBlockBreaking();
            if (Config.I.minerWalk && !danger && Move.safeAhead(w, p, dir)) { Move.set(mc, true); status = "Maju"; }
            else { Move.set(mc, false); status = danger ? "Cairan di depan, berhenti" : "Menunggu"; }
        }
    }

    static void selectBestTool(ClientPlayerEntity p, BlockState state) {
        float best = 0; int slot = -1;
        for (int i = 0; i < 9; i++) {
            ItemStack s = p.getInventory().getStack(i);
            if (s.isEmpty()) continue;
            if (s.isDamageable() && s.getMaxDamage() - s.getDamage() <= 2) continue;
            float sp = s.getMiningSpeedMultiplier(state);
            if (sp > best) { best = sp; slot = i; }
        }
        if (slot >= 0 && best > 1.0f) p.getInventory().selectedSlot = slot;
    }
}
