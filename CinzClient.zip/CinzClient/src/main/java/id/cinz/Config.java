package id.cinz;

import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import java.nio.file.*;

public class Config {
    // Name changer
    public boolean nameEnabled = true;
    public String fakeName = "Cinz";
    public String nameMode = "RAINBOW";
    public String color1 = "#FF55FF", color2 = "#55FFFF";
    public boolean bold, italic, underline;
    public double speed = 1.0;
    // Miner
    public String minerMode = "NORMAL"; // NORMAL | 3X3
    public boolean minerWalk = true;
    public double minerMinHealth = 6;
    // Builder
    public boolean buildWalk = true;
    public int buildDelay = 2;
    // Spotify
    public String spotifyClientId = "", refreshToken = "", spotifyDevice = "";
    public boolean showLyrics = true;

    public static Config I = new Config();
    static final Gson G = new GsonBuilder().setPrettyPrinting().create();

    static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("cinzclient.json"); }

    public static void load() {
        try {
            if (Files.exists(file())) {
                Config c = G.fromJson(Files.readString(file()), Config.class);
                if (c != null) I = c;
            }
        } catch (Exception ignored) {}
    }

    public static synchronized void save() {
        try { Files.writeString(file(), G.toJson(I)); } catch (Exception ignored) {}
    }
}
