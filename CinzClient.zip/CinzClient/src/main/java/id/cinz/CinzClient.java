package id.cinz;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class CinzClient implements ClientModInitializer {
    static KeyBinding keyMiner, keyBuild;

    @Override
    public void onInitializeClient() {
        Config.load();
        keyMiner = KeyBindingHelper.registerKeyBinding(new KeyBinding("Toggle AutoMiner", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_V, "Cinz Client"));
        keyBuild = KeyBindingHelper.registerKeyBinding(new KeyBinding("Toggle AutoBuilder", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_B, "Cinz Client"));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (keyMiner.wasPressed()) AutoMiner.toggle();
            while (keyBuild.wasPressed()) AutoBuilder.toggle();
            if (mc.player == null) { AutoMiner.enabled = false; AutoBuilder.running = false; return; }
            AutoMiner.tick(mc);
            AutoBuilder.tick(mc);
        });

        HudRenderCallback.EVENT.register(Hud::render);

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
            dispatcher.register(ClientCommandManager.literal("cinz")
                .executes(ctx -> { Commands.help(); return 1; })
                .then(ClientCommandManager.argument("args", StringArgumentType.greedyString())
                    .executes(ctx -> Commands.run(StringArgumentType.getString(ctx, "args"))))));

        Spotify.init();
    }

    public static void msg(String s) { msgText(Text.literal("§d[Cinz] §f" + s)); }

    public static void msgText(Text t) {
        MinecraftClient mc = MinecraftClient.getInstance();
        mc.execute(() -> { if (mc.player != null) mc.player.sendMessage(t, false); });
    }
}
