package id.cinz;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import java.util.List;

public class Hud {
    public static void render(DrawContext ctx, RenderTickCounter tc) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;
        TextRenderer tr = mc.textRenderer;
        int y = 4;
        ctx.drawTextWithShadow(tr, Text.literal("Cinz ").formatted(Formatting.LIGHT_PURPLE).append(NameChanger.build(Config.I.fakeName)), 4, y, 0xFFFFFF); y += 11;
        if (AutoMiner.enabled) { ctx.drawTextWithShadow(tr, "Miner [" + Config.I.minerMode + "]: " + AutoMiner.status, 4, y, 0x55FF55); y += 10; }
        if (AutoBuilder.running) { ctx.drawTextWithShadow(tr, "Builder: " + AutoBuilder.status, 4, y, 0x55FFFF); y += 10; }

        if (Spotify.connected && !Spotify.title.isEmpty()) {
            String np = (Spotify.playing ? "> " : "|| ") + Spotify.title + " - " + Spotify.artist;
            ctx.drawTextWithShadow(tr, np, 4, y, 0x1DB954); y += 10;
            long pos = Spotify.position(), dur = Math.max(1, Spotify.durationMs);
            int bw = 120;
            ctx.fill(4, y, 4 + bw, y + 2, 0x66FFFFFF);
            ctx.fill(4, y, 4 + (int) (bw * pos / dur), y + 2, 0xFF1DB954);
            y += 6;
        }

        if (Config.I.showLyrics && Spotify.connected) {
            int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
            int ly = sh - 90;
            List<Spotify.Line> l = Spotify.lyrics;
            int idx = Spotify.lineIndex();
            if (idx >= 0 || !l.isEmpty()) {
                draw(ctx, tr, idx - 1 >= 0 ? l.get(idx - 1).text() : "", sw, ly, 0x888888);
                draw(ctx, tr, idx >= 0 ? l.get(idx).text() : "", sw, ly + 11, 0xFFFFFF);
                draw(ctx, tr, idx + 1 < l.size() ? l.get(idx + 1).text() : "", sw, ly + 22, 0x888888);
            } else if (!Spotify.lyricsInfo.isEmpty()) {
                draw(ctx, tr, Spotify.lyricsInfo, sw, ly + 11, 0xAAAAAA);
            }
        }
    }

    static void draw(DrawContext ctx, TextRenderer tr, String s, int sw, int y, int color) {
        if (s == null || s.isEmpty()) return;
        ctx.drawTextWithShadow(tr, s, (sw - tr.getWidth(s)) / 2, y, color);
    }
}
