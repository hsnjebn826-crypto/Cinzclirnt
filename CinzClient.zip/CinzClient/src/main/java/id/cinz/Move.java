package id.cinz;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

public class Move {
    static boolean pressed;

    public static void set(MinecraftClient mc, boolean on) {
        if (on) { mc.options.forwardKey.setPressed(true); pressed = true; }
        else if (pressed) {
            mc.options.forwardKey.setPressed(false);
            mc.options.jumpKey.setPressed(false);
            pressed = false;
        }
    }

    /** Aman maju: tidak ada cairan di depan dan tidak ada jurang >= 2 blok. */
    public static boolean safeAhead(ClientWorld w, ClientPlayerEntity p, Direction dir) {
        BlockPos f = p.getBlockPos().offset(dir);
        if (!w.getFluidState(f).isEmpty() || !w.getFluidState(f.up()).isEmpty() || !w.getFluidState(f.down()).isEmpty()) return false;
        return !(w.getBlockState(f.down()).isAir() && w.getBlockState(f.down(2)).isAir());
    }
}
