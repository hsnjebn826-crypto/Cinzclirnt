package id.cinz;

import net.minecraft.client.MinecraftClient;
import java.util.*;

public class Commands {
    static final String[] HELP = {
        "§d== Cinz Client ==",
        "§f/cinz name set <nama> | mode <static|rainbow|gradient|wave|pulse|fire|glitch>",
        "§f/cinz name color <warna1> [warna2] | style <bold|italic|underline> | speed <0.1-10> | on | off | colors",
        "§f/cinz mine on|off | mode normal|3x3 | walk on|off",
        "§f/cinz build list | load <file> | here | start | stop | status",
        "§f/cinz music login <clientId> | play | pause | next | prev | playlist <link> | vol <0-100>",
        "§f/cinz music shuffle on|off | devices | device <nama> | lyrics on|off",
        "§7Keybind: V = toggle miner, B = toggle builder"
    };

    static void help() { for (String s : HELP) CinzClient.msg(s); }
    static void need(String[] a, int n) { if (a.length < n) throw new IllegalArgumentException("Argumen kurang. Ketik /cinz"); }

    public static int run(String raw) {
        String[] a = raw.trim().split("\\s+");
        try {
            switch (a[0].toLowerCase()) {
                case "name" -> name(a);
                case "mine" -> mine(a);
                case "build" -> build(a);
                case "music" -> music(a);
                default -> help();
            }
        } catch (Exception e) { CinzClient.msg("§cError: " + e.getMessage()); }
        return 1;
    }

    static void name(String[] a) {
        need(a, 2);
        Config c = Config.I;
        switch (a[1].toLowerCase()) {
            case "set" -> { need(a, 3); String n = String.join(" ", Arrays.copyOfRange(a, 2, a.length)); c.fakeName = n.length() > 32 ? n.substring(0, 32) : n; c.nameEnabled = true; }
            case "mode" -> { need(a, 3); c.nameMode = NameChanger.Mode.valueOf(a[2].toUpperCase()).name(); }
            case "color" -> { need(a, 3); NameChanger.parse(a[2]); c.color1 = a[2]; if (a.length > 3) { NameChanger.parse(a[3]); c.color2 = a[3]; } }
            case "style" -> { need(a, 3);
                switch (a[2].toLowerCase()) { case "bold" -> c.bold = !c.bold; case "italic" -> c.italic = !c.italic; case "underline" -> c.underline = !c.underline; default -> throw new IllegalArgumentException("bold|italic|underline"); } }
            case "speed" -> { need(a, 3); c.speed = Math.max(0.1, Math.min(10, Double.parseDouble(a[2]))); }
            case "on" -> c.nameEnabled = true;
            case "off" -> c.nameEnabled = false;
            case "colors" -> { CinzClient.msg("Warna: " + String.join(", ", NameChanger.PRESETS.keySet()) + " atau #RRGGBB"); return; }
            default -> throw new IllegalArgumentException("sub-command tidak dikenal");
        }
        Config.save();
        CinzClient.msg("Name: " + c.fakeName + " | mode " + c.nameMode + " | " + c.color1 + " -> " + c.color2 + " (lihat dengan F5)");
    }

    static void mine(String[] a) {
        need(a, 2);
        switch (a[1].toLowerCase()) {
            case "on" -> AutoMiner.start();
            case "off" -> AutoMiner.stop("dimatikan");
            case "mode" -> { need(a, 3);
                String m = a[2].toLowerCase();
                if (m.equals("normal")) Config.I.minerMode = "NORMAL";
                else if (m.equals("3x3")) Config.I.minerMode = "3X3";
                else throw new IllegalArgumentException("normal atau 3x3");
                Config.save(); CinzClient.msg("Miner mode: " + Config.I.minerMode); }
            case "walk" -> { need(a, 3); Config.I.minerWalk = a[2].equalsIgnoreCase("on"); Config.save(); CinzClient.msg("Auto maju: " + Config.I.minerWalk); }
            default -> throw new IllegalArgumentException("on|off|mode|walk");
        }
    }

    static void build(String[] a) {
        need(a, 2);
        MinecraftClient mc = MinecraftClient.getInstance();
        switch (a[1].toLowerCase()) {
            case "list" -> { List<String> l = AutoBuilder.list(); CinzClient.msg(l.isEmpty() ? "Kosong. Taruh .nbt/.schem di " + AutoBuilder.dir() : "File: " + String.join(", ", l)); }
            case "load" -> { need(a, 3); AutoBuilder.load(String.join(" ", Arrays.copyOfRange(a, 2, a.length))); }
            case "here" -> { if (mc.player != null) AutoBuilder.setOrigin(mc.player.getBlockPos()); }
            case "start" -> AutoBuilder.start(mc);
            case "stop" -> AutoBuilder.stop("dimatikan");
            case "status" -> CinzClient.msg("Builder: " + AutoBuilder.report());
            default -> throw new IllegalArgumentException("list|load|here|start|stop|status");
        }
    }

    static void music(String[] a) {
        need(a, 2);
        switch (a[1].toLowerCase()) {
            case "login" -> { need(a, 3); Spotify.login(a[2]); }
            case "play" -> Spotify.play(null);
            case "pause" -> Spotify.pause();
            case "next" -> Spotify.next();
            case "prev" -> Spotify.prev();
            case "playlist" -> { need(a, 3); Spotify.play(a[2]); }
            case "vol" -> { need(a, 3); Spotify.volume(Integer.parseInt(a[2])); }
            case "shuffle" -> { need(a, 3); Spotify.shuffle(a[2].equalsIgnoreCase("on")); }
            case "devices" -> Spotify.devices();
            case "device" -> { need(a, 3); Config.I.spotifyDevice = String.join(" ", Arrays.copyOfRange(a, 2, a.length)); Config.save(); CinzClient.msg("Device: " + Config.I.spotifyDevice); }
            case "lyrics" -> { need(a, 3); Config.I.showLyrics = a[2].equalsIgnoreCase("on"); Config.save(); }
            default -> throw new IllegalArgumentException("login|play|pause|next|prev|playlist|vol|shuffle|devices|device|lyrics");
        }
    }
}
