package id.cinz.mixin;

import id.cinz.Config;
import id.cinz.NameChanger;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerEntity.class)
public abstract class PlayerDisplayNameMixin {
    @Inject(method = "getDisplayName", at = @At("RETURN"), cancellable = true)
    private void cinz$displayName(CallbackInfoReturnable<Text> cir) {
        if (!Config.I.nameEnabled) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null && (Object) this == mc.player) {
            cir.setReturnValue(NameChanger.build(Config.I.fakeName));
        }
    }
}
