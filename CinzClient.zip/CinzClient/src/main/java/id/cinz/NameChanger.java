package id.cinz;

import net.minecraft.text.*;
import java.awt.Color;
import java.util.*;

public class NameChanger {
    public enum Mode { STATIC, RAINBOW, GRADIENT, WAVE, PULSE, FIRE, GLITCH }

    public static final Map<String, Integer> PRESETS = new LinkedHashMap<>();
    static {
        PRESETS.put("red", 0xFF5555); PRESETS.put("orange", 0xFFAA00); PRESETS.put("yellow", 0xFFFF55);
        PRESETS.put("lime", 0x55FF55); PRESETS.put("green", 0x00AA00); PRESETS.put("aqua", 0x55FFFF);
        PRESETS.put("blue", 0x5555FF); PRESETS.put("purple", 0xAA00AA); PRESETS.put("pink", 0xFF55FF);
        PRESETS.put("white", 0xFFFFFF); PRESETS.put("gold", 0xFFD700); PRESETS.put("gray", 0xAAAAAA);
    }

    public static int parse(String s) {
        Integer p = PRESETS.get(s.toLowerCase());
        if (p != null) return p;
        String h = s.startsWith("#") ? s.substring(1) : s;
        if (h.length() != 6) throw new IllegalArgumentException("Warna tidak valid: " + s + " (pakai nama atau #RRGGBB)");
        return Integer.parseInt(h, 16);
    }

    static int lerp(int a, int b, double t) {
        t = Math.max(0, Math.min(1, t));
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return (r << 16) | (g << 8) | bl;
    }

    static double tri(double x) { x = x % 1.0; if (x < 0) x += 1; return x < 0.5 ? x * 2 : 2 - x * 2; }

    public static MutableText build(String name) {
        Config c = Config.I;
        Mode m;
        try { m = Mode.valueOf(c.nameMode.toUpperCase()); } catch (Exception e) { m = Mode.STATIC; }
        int c1, c2;
        try { c1 = parse(c.color1); c2 = parse(c.color2); } catch (Exception e) { c1 = 0xFFFFFF; c2 = 0xFFFFFF; }
        double t = System.currentTimeMillis() / 1000.0 * c.speed;
        MutableText out = Text.empty();
        int n = Math.max(1, name.length());
        for (int i = 0; i < name.length(); i++) {
            int rgb;
            switch (m) {
                case RAINBOW -> rgb = Color.HSBtoRGB((float) ((t * 0.3 + i * 0.07) % 1.0), 0.8f, 1f) & 0xFFFFFF;
                case GRADIENT -> rgb = lerp(c1, c2, tri((double) i / n + t * 0.3));
                case WAVE -> rgb = lerp(c1, c2, (Math.sin(t * 3 + i * 0.6) + 1) / 2);
                case PULSE -> rgb = lerp(0x000000, c1, 0.35 + 0.65 * (Math.sin(t * 3) + 1) / 2);
                case FIRE -> rgb = lerp(0xFF2200, 0xFFDD00, (Math.sin(t * 6 + i * 1.3) + 1) / 2);
                case GLITCH -> rgb = (((int) (t * 8) + i * 3) % 9 == 0) ? 0xFFFFFF : c1;
                default -> rgb = c1;
            }
            Style s = Style.EMPTY.withColor(rgb).withBold(c.bold).withItalic(c.italic).withUnderline(c.underline);
            out.append(Text.literal(String.valueOf(name.charAt(i))).setStyle(s));
        }
        return out;
    }
}
